﻿namespace SistemaDeControleDeFrequencia.DTOs.Setor {
    public class SetorUpdateDTO {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string NomeNucleo { get; set; }
    }
}