﻿using SistemaDeControleDeFrequencia.DTOs.Setor;

namespace SistemaDeControleDeFrequencia.DTOs.Nucleo
{
    public class NucleoUpdateDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }    
        public string Cidade { get; set; }
        
    }
}
