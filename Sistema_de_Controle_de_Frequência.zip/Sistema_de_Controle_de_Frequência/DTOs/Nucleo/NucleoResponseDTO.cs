﻿namespace SistemaDeControleDeFrequencia.DTOs.Nucleo
{
    public class NucleoResponseDTO
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Cidade { get; set; }
    }
}
