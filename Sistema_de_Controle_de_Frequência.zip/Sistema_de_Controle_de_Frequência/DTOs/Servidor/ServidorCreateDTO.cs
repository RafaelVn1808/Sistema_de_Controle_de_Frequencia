﻿using Sistema_de_Controle_de_Frequência.Models;

namespace SistemaDeControleDeFrequencia.DTOs.Servidor
{
    public class ServidorCreateDTO
    {

        public string Nome { get; set; }
        public string Matricula { get; set; }
        public string NomeSetor { get; set; }


    }
}
