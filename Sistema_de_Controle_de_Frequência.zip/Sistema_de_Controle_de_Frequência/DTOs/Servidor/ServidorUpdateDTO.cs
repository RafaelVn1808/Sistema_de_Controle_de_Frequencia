﻿namespace SistemaDeControleDeFrequencia.DTOs.Servidor {
    public class ServidorUpdateDTO {

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Matricula { get; set; }
        public string NomeSetor { get; set; }
    }
}
