﻿namespace SistemaDeControleDeFrequencia.DTOs.StatusFrequencia
{
    public class StatusFrequenciaCreateDTO
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
    }
}
