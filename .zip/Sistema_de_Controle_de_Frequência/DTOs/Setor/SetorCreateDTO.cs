﻿namespace SistemaDeControleDeFrequencia.DTOs.Setor {
    public class SetorCreateDTO {
        public string Nome { get; set; }
        public string NomeNucleo { get; set; }
    }
}