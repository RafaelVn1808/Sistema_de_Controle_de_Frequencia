﻿namespace SistemaDeControleDeFrequencia.DTOs.Frequencia {
    public class FrequenciaCreateDTO {

        public string MesReferencia { get; set; }
        public int SetorId { get; set; }

    }
}
