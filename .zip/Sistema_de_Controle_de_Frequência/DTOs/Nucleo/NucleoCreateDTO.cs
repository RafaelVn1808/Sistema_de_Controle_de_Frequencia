﻿namespace SistemaDeControleDeFrequencia.DTOs.Nucleo
{
    public class NucleoCreateDTO
    {
        public string Nome { get; set; }
        public string Cidade { get; set; }
                
    }
}
